From http://users.hol.gr/%7Etron/software/dialer/top.htm
